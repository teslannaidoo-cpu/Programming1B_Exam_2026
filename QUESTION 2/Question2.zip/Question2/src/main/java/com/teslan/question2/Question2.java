package com.teslan.question2;

public class Question2 {

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(() -> {
            new MattressSalesGUI().setVisible(true);
        });

    }
}